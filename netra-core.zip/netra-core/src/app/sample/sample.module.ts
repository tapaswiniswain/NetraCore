import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Import Custom Modules
import { SampleRoutingModule } from './sample-routing.module';

// Import Components
import { SampleComponent } from './sample.component';

@NgModule({
  imports: [
    CommonModule,
    SampleRoutingModule
  ],
  declarations: [SampleComponent]
})
export class SampleModule { }
