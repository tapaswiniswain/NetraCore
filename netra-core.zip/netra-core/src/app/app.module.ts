import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

// Import Custom Modules
import { AppRoutingModule } from './app-routing.module';
import {LayoutsModule} from './layouts/layouts.module';

// Import Components
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    LayoutsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
