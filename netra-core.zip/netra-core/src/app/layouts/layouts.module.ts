import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Import Custom Modules
import { LayoutsRoutingModule } from './layouts-routing.module';

// Import Components
import { LayoutsComponent } from './layouts.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SideBarComponent } from './side-bar/side-bar.component';

@NgModule({
  imports: [
    CommonModule,
    LayoutsRoutingModule
  ],
  declarations: [LayoutsComponent, HeaderComponent, FooterComponent, SideBarComponent],
  exports: [LayoutsComponent]
})
export class LayoutsModule { }
