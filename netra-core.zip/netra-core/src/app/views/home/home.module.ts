import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Import Custom Modules
import { HomeRoutingModule } from './home-routing.module';

// Import Components
import { HomeComponent } from './home.component';

@NgModule({
  imports: [
    CommonModule,
    HomeRoutingModule
  ],
  declarations: [HomeComponent]
})
export class HomeModule { }
